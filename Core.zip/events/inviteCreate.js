const Utils = require("../modules/utils");

module.exports = async (bot, invite) => {
    Utils.updateInviteCache(bot)
}
// https://directleaks.net